/*
 * Smart Expense Tracker - Vercel/browser API compatibility layer.
 *
 * The original application expects Spring Boot REST endpoints. Vercel's
 * static hosting cannot run that Spring Boot server, so this layer provides
 * the same JSON API contract in the browser using localStorage.
 *
 * This is intended for a deployable academic/demo version, not as a
 * replacement for a secure production financial backend.
 */
(() => {
  const nativeFetch = window.fetch.bind(window);
  const KEYS = {
    users: 'set_users_v1',
    transactions: 'set_transactions_v1',
    session: 'set_session_v1'
  };

  const categories = [
    {id: 1, name: 'Salary', type: 'INCOME'},
    {id: 2, name: 'Freelance', type: 'INCOME'},
    {id: 3, name: 'Business', type: 'INCOME'},
    {id: 4, name: 'Other Income', type: 'INCOME'},
    {id: 5, name: 'Food', type: 'EXPENSE'},
    {id: 6, name: 'Transport', type: 'EXPENSE'},
    {id: 7, name: 'Education', type: 'EXPENSE'},
    {id: 8, name: 'Shopping', type: 'EXPENSE'},
    {id: 9, name: 'Bills', type: 'EXPENSE'},
    {id: 10, name: 'Entertainment', type: 'EXPENSE'},
    {id: 11, name: 'Healthcare', type: 'EXPENSE'},
    {id: 12, name: 'Other', type: 'EXPENSE'}
  ];

  const read = (key, fallback) => {
    try { return JSON.parse(localStorage.getItem(key) || JSON.stringify(fallback)); }
    catch (_) { return fallback; }
  };
  const write = (key, value) => localStorage.setItem(key, JSON.stringify(value));
  const now = () => new Date().toISOString();
  const response = (data, status = 200, message = '') => new Response(
    JSON.stringify({success: status >= 200 && status < 300, message, data}),
    {status, headers: {'Content-Type': 'application/json'}}
  );
  const error = (message, status = 400, fieldErrors = null) => new Response(
    JSON.stringify({success: false, message, ...(fieldErrors ? {fieldErrors} : {})}),
    {status, headers: {'Content-Type': 'application/json'}}
  );
  const users = () => read(KEYS.users, []);
  const txs = () => read(KEYS.transactions, []);
  const sessionId = () => Number(localStorage.getItem(KEYS.session) || 0) || null;
  const currentUser = () => users().find(u => u.id === sessionId()) || null;
  const publicUser = u => u && ({id:u.id, username:u.username, email:u.email, createdAt:u.createdAt});

  const sha256 = async text => {
    const data = new TextEncoder().encode(text);
    const hash = await crypto.subtle.digest('SHA-256', data);
    return [...new Uint8Array(hash)].map(b => b.toString(16).padStart(2, '0')).join('');
  };

  const getCategory = id => categories.find(c => c.id === Number(id));
  const userTxs = () => {
    const u = currentUser();
    return u ? txs().filter(t => t.userId === u.id) : [];
  };
  const mapTx = t => ({...t, amount: Number(t.amount), categoryName: getCategory(t.categoryId)?.name || 'Unknown'});

  function monthlySummary(list) {
    const out = [];
    const d = new Date();
    d.setDate(1);
    for (let i = 5; i >= 0; i--) {
      const x = new Date(d.getFullYear(), d.getMonth() - i, 1);
      const year = x.getFullYear(), month = x.getMonth();
      const monthTx = list.filter(t => {
        const td = new Date(t.transactionDate + 'T00:00:00');
        return td.getFullYear() === year && td.getMonth() === month;
      });
      const income = monthTx.filter(t => t.type === 'INCOME').reduce((s,t) => s + Number(t.amount), 0);
      const expense = monthTx.filter(t => t.type === 'EXPENSE').reduce((s,t) => s + Number(t.amount), 0);
      out.push({monthLabel:x.toLocaleString('en-US',{month:'short'}), year, monthValue:month+1, income, expense, net:income-expense});
    }
    return out;
  }

  function tableData(table) {
    const allUsers = users();
    const allTx = txs().map(t => ({...t, category_id:t.categoryId, user_id:t.userId, created_at:t.createdAt, transaction_date:t.transactionDate}));
    if (table === 'users') {
      const rows = allUsers.map(u => ({id:u.id, username:u.username, email:u.email, password:u.password, created_at:u.createdAt}));
      return {columns:['id','username','email','password','created_at'], rows, rowCount:rows.length};
    }
    if (table === 'categories') {
      const rows = categories.map(c => ({id:c.id,name:c.name,type:c.type}));
      return {columns:['id','name','type'], rows, rowCount:rows.length};
    }
    const rows = allTx.map(t => ({id:t.id,user_id:t.userId,category_id:t.categoryId,amount:t.amount,type:t.type,description:t.description,transaction_date:t.transactionDate,created_at:t.createdAt}));
    return {columns:['id','user_id','category_id','amount','type','description','transaction_date','created_at'], rows, rowCount:rows.length};
  }

  function schema(table) {
    const defs = {
      users:[
        ['id','BIGINT','NO','PRI',null,'auto_increment'],['username','VARCHAR(50)','NO','UNI',null,''],['email','VARCHAR(100)','NO','UNI',null,''],['password','VARCHAR(255)','NO','',null,''],['created_at','DATETIME','NO','',null,'']
      ],
      categories:[
        ['id','BIGINT','NO','PRI',null,'auto_increment'],['name','VARCHAR(50)','NO','',null,''],['type','VARCHAR(20)','NO','',null,'']
      ],
      transactions:[
        ['id','BIGINT','NO','PRI',null,'auto_increment'],['user_id','BIGINT','NO','MUL',null,''],['category_id','BIGINT','NO','MUL',null,''],['amount','DECIMAL(15,2)','NO','',null,''],['type','VARCHAR(20)','NO','',null,''],['description','VARCHAR(255)','YES','',null,''],['transaction_date','DATE','NO','',null,''],['created_at','DATETIME','NO','',null,'']
      ]
    };
    return (defs[table] || defs.transactions).map(([Field,Type,Null,Key,Default,Extra]) => ({Field,Type,Null,Key,Default,Extra}));
  }

  async function handle(input, init = {}) {
    const url = new URL(input, window.location.origin);
    const path = url.pathname;
    const method = (init.method || 'GET').toUpperCase();
    let body = {};
    try { body = init.body ? JSON.parse(init.body) : {}; } catch (_) {}

    // Auth
    if (path === '/api/auth/me' && method === 'GET') {
      const u = currentUser();
      return u ? response(publicUser(u), 200, 'Authenticated user retrieved.') : error('Not authenticated.', 401);
    }
    if (path === '/api/auth/register' && method === 'POST') {
      const username = String(body.username || '').trim();
      const email = String(body.email || '').trim().toLowerCase();
      if (username.length < 3) return error('Username must be at least 3 characters.',400,{username:'Username must be at least 3 characters'});
      if (!/^\S+@\S+\.\S+$/.test(email)) return error('Email format is invalid.',400,{email:'Email format is invalid'});
      if (String(body.password || '').length < 6) return error('Password must be at least 6 characters long.',400,{password:'Password must be at least 6 characters long'});
      if (body.password !== body.confirmPassword) return error('Passwords do not match.',400,{confirmPassword:'Passwords do not match'});
      const list = users();
      if (list.some(u => u.username.toLowerCase() === username.toLowerCase())) return error('Username already exists.',400);
      if (list.some(u => u.email.toLowerCase() === email)) return error('Email already exists.',400);
      const u = {id: list.length ? Math.max(...list.map(x=>x.id))+1 : 1, username, email, password: await sha256(body.password), createdAt:now()};
      list.push(u); write(KEYS.users,list);
      return response(publicUser(u),201,'User registered successfully! You can now log in.');
    }
    if (path === '/api/auth/login' && method === 'POST') {
      const id = String(body.usernameOrEmail || '').trim().toLowerCase();
      const hash = await sha256(String(body.password || ''));
      const u = users().find(x => (x.username.toLowerCase() === id || x.email.toLowerCase() === id) && x.password === hash);
      if (!u) return error('Invalid username/email or password.',401);
      localStorage.setItem(KEYS.session,String(u.id));
      return response(publicUser(u),200,'Login successful!');
    }
    if (path === '/api/auth/logout' && method === 'POST') {
      localStorage.removeItem(KEYS.session);
      return response(null,200,'Logged out successfully.');
    }

    // Categories
    if (path === '/api/categories' && method === 'GET') {
      const type = url.searchParams.get('type');
      return response(type ? categories.filter(c=>c.type===type) : categories,200,'Categories retrieved successfully.');
    }
    if (path === '/api/categories' && method === 'POST') {
      return error('Categories are fixed in the Vercel demo version.',400);
    }

    // Transaction endpoints
    if (path === '/api/transactions' && method === 'GET') {
      if (!currentUser()) return error('Not authenticated.',401);
      let list = userTxs().map(mapTx);
      const type=url.searchParams.get('type'), categoryId=url.searchParams.get('categoryId'), start=url.searchParams.get('startDate'), end=url.searchParams.get('endDate'), keyword=url.searchParams.get('keyword');
      if (type) list=list.filter(t=>t.type===type);
      if (categoryId) list=list.filter(t=>t.categoryId===Number(categoryId));
      if (start) list=list.filter(t=>t.transactionDate>=start);
      if (end) list=list.filter(t=>t.transactionDate<=end);
      if (keyword) list=list.filter(t=>(t.description||'').toLowerCase().includes(keyword.toLowerCase()));
      list.sort((a,b)=>(b.transactionDate||'').localeCompare(a.transactionDate||'') || String(b.createdAt).localeCompare(String(a.createdAt)));
      return response(list,200,'Transactions retrieved successfully.');
    }
    if (path === '/api/transactions' && method === 'POST') {
      const u=currentUser();
      if (!u) return error('Not authenticated.',401);
      const cat=getCategory(body.categoryId);
      const amount=Number(body.amount);
      if (!cat || cat.type!==body.type) return error('Selected category does not match transaction type.',400);
      if (!Number.isFinite(amount) || amount<=0) return error('Amount must be greater than zero.',400);
      if (!body.transactionDate) return error('Transaction date is required.',400);
      const list=txs();
      const t={id:list.length?Math.max(...list.map(x=>x.id))+1:1,userId:u.id,categoryId:cat.id,amount:Number(amount.toFixed(2)),type:body.type,description:String(body.description||'').trim(),transactionDate:body.transactionDate,createdAt:now()};
      list.push(t); write(KEYS.transactions,list);
      return response(mapTx(t),201,'Transaction created successfully.');
    }
    const match=path.match(/^\/api\/transactions\/(\d+)$/);
    if (match) {
      const id=Number(match[1]); const u=currentUser();
      if (!u) return error('Not authenticated.',401);
      const list=txs(); const idx=list.findIndex(t=>t.id===id && t.userId===u.id);
      if (idx<0) return error('Transaction not found.',404);
      if (method==='GET') return response(mapTx(list[idx]),200,'Transaction retrieved.');
      if (method==='PUT') {
        const cat=getCategory(body.categoryId), amount=Number(body.amount);
        if (!cat || cat.type!==body.type || !Number.isFinite(amount) || amount<=0 || !body.transactionDate) return error('Invalid transaction data.',400);
        list[idx]={...list[idx],categoryId:cat.id,amount:Number(amount.toFixed(2)),type:body.type,description:String(body.description||'').trim(),transactionDate:body.transactionDate};
        write(KEYS.transactions,list); return response(mapTx(list[idx]),200,'Transaction updated successfully.');
      }
      if (method==='DELETE') { list.splice(idx,1); write(KEYS.transactions,list); return response(null,200,'Transaction deleted successfully.'); }
    }

    // Dashboard
    if (path.startsWith('/api/dashboard/')) {
      const u=currentUser(); if (!u) return error('Not authenticated.',401);
      const list=userTxs().map(mapTx);
      if (path==='/api/dashboard/summary') {
        const income=list.filter(t=>t.type==='INCOME').reduce((s,t)=>s+t.amount,0);
        const expense=list.filter(t=>t.type==='EXPENSE').reduce((s,t)=>s+t.amount,0);
        const recent=[...list].sort((a,b)=>(b.transactionDate||'').localeCompare(a.transactionDate||'') || String(b.createdAt).localeCompare(String(a.createdAt))).slice(0,5);
        return response({totalIncome:income,totalExpense:expense,netBalance:income-expense,recentTransactions:recent},200,'Dashboard summary retrieved.');
      }
      if (path==='/api/dashboard/category-expenses') {
        const map=new Map(); list.filter(t=>t.type==='EXPENSE').forEach(t=>map.set(t.categoryName,(map.get(t.categoryName)||0)+t.amount));
        return response([...map.entries()].sort((a,b)=>b[1]-a[1]).map(([categoryName,totalAmount])=>({categoryName,totalAmount})),200,'Category expense analytics retrieved.');
      }
      if (path==='/api/dashboard/monthly-summary') return response(monthlySummary(list),200,'Monthly summary analytics retrieved.');
    }

    // Database explorer (demo/local data, not MySQL)
    if (path==='/api/database/info' && method==='GET') return response({databaseName:'Browser Local Storage',status:'ONLINE',userCount:users().length,transactionCount:txs().length},200,'Database information retrieved.');
    const tableMatch=path.match(/^\/api\/database\/table\/(users|categories|transactions)$/);
    if (tableMatch && method==='GET') return response(tableData(tableMatch[1]),200,'Table data retrieved.');
    const schemaMatch=path.match(/^\/api\/database\/schema\/(users|categories|transactions)$/);
    if (schemaMatch && method==='GET') return response(schema(schemaMatch[1]),200,'Table schema retrieved.');
    if (path==='/api/database/query' && method==='POST') {
      const sql=String(body.query||'').trim().toLowerCase();
      let data;
      if (sql.includes('from users')) data=tableData('users');
      else if (sql.includes('from categories')) data=tableData('categories');
      else if (sql.includes('from transactions')) data=tableData('transactions');
      else if (sql.includes('group by type')) {
        const list=txs(); const rows=['INCOME','EXPENSE'].map(type=>({type,count:list.filter(t=>t.type===type).length,total_amount:list.filter(t=>t.type===type).reduce((s,t)=>s+Number(t.amount),0)}));
        data={columns:['type','count','total_amount'],rows,rowCount:rows.length};
      } else if (sql.includes('group by c.name')) {
        const m=new Map(); txs().filter(t=>t.type==='EXPENSE').forEach(t=>m.set(getCategory(t.categoryId).name,(m.get(getCategory(t.categoryId).name)||0)+Number(t.amount)));
        const rows=[...m.entries()].map(([name,total_expense])=>({name,total_expense})).sort((a,b)=>b.total_expense-a.total_expense);
        data={columns:['name','total_expense'],rows,rowCount:rows.length};
      } else return error('Only the included demo SELECT queries are supported in the Vercel version.',400);
      return response(data,200,'Query executed successfully.');
    }
    if (path==='/api/database/seed-demo' && method==='POST') {
      const u=currentUser(); if (!u) return error('Log in first to seed demo data.',401);
      const list=txs(); const today=new Date(); const date=n=>{const d=new Date(today);d.setDate(d.getDate()-n);return d.toISOString().slice(0,10)};
      const demo=[
        {categoryId:1,amount:50000,type:'INCOME',description:'Monthly company salary',transactionDate:date(0)},
        {categoryId:5,amount:5000,type:'EXPENSE',description:'Monthly groceries & dining',transactionDate:date(1)},
        {categoryId:6,amount:2000,type:'EXPENSE',description:'Metro card recharge & fuel',transactionDate:date(2)},
        {categoryId:7,amount:3000,type:'EXPENSE',description:'Books and online course',transactionDate:date(3)}
      ];
      let next=list.length?Math.max(...list.map(x=>x.id))+1:1;
      demo.forEach(d=>list.push({id:next++,userId:u.id,...d,createdAt:now()})); write(KEYS.transactions,list);
      return response(null,200,'Demo data seeded successfully!');
    }

    // Non-API requests remain normal fetches.
    return nativeFetch(input, init);
  }

  window.fetch = (input, init) => {
    try {
      const url = new URL(input, window.location.origin);
      if (url.pathname.startsWith('/api/')) return handle(input, init);
    } catch (_) {}
    return nativeFetch(input, init);
  };
})();
