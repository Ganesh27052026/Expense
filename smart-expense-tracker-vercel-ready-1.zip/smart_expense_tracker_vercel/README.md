# Smart Expense Tracker — Vercel Ready

This package is ready to deploy as a static Vercel website.

## Deploy to Vercel

1. Upload this folder/repository to GitHub, or import the ZIP contents into a Git repository.
2. In Vercel, choose **Add New → Project** and select the repository.
3. Framework Preset: **Other**.
4. Build Command: **leave empty**.
5. Output Directory: **.**
6. Deploy.

No Java, Maven, or MySQL installation is needed for the Vercel version.

## Important architecture note

The original project is a Spring Boot + MySQL application. Vercel does not run a traditional Spring Boot server directly. The Vercel version therefore uses browser local storage for the demo application's data and keeps the original Java backend under `backend/` for local/Java deployment.

Data is stored in the browser on the device/browser where the site is opened. It is not a production cloud database.

## Main files

- `index.html` — application UI
- `css/style.css` — styling
- `js/app.js` — UI/application logic
- `js/vercel-api.js` — Vercel/browser API compatibility layer using localStorage
- `vercel.json` — Vercel configuration
- `backend/` — original Spring Boot + MySQL project
